def sell_wood(helico, field, cost=30):
    if field.cells[helico.x][helico.y] == 1:
        field.cells[helico.x][helico.y] = 0
        helico.score += cost
        return True
    return False