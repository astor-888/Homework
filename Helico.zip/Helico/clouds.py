from utils import randcell, randbool
from random import randint as rand


class Cloud:
    def __init__(self, x, y, thunder=False, ttl=None):
        self.x = x
        self.y = y
        self.thunder = thunder
        self.ttl = ttl if ttl is not None else rand(60, 150)

    def move(self, w, h):
        self.x += rand(-1, 1)
        self.y += rand(-1, 1)
        self.x = max(0, min(h - 1, self.x))
        self.y = max(0, min(w - 1, self.y))
        self.ttl -= 1
        # гроза меняется редко
        if randbool(1, 40):
            self.thunder = not self.thunder


class Clouds:
    def __init__(self, w, h, n=6):
        self.w = w
        self.h = h
        self.clouds = []
        for _ in range(n):
            cx, cy = randcell(w, h)
            self.clouds.append(Cloud(cx, cy))

    def update(self, field):
        for c in self.clouds[:]:
            c.move(self.w, self.h)
            # гроза поджигает дерево (редко)
            if c.thunder and randbool(1, 60):
                if field.cells[c.x][c.y] == 1:
                    field.cells[c.x][c.y] = 5
            # дождь тушит пожар (редко)
            elif not c.thunder and randbool(1, 60):
                if field.cells[c.x][c.y] == 5:
                    field.cells[c.x][c.y] = 0
            if c.ttl <= 0:
                self.clouds.remove(c)
        # новое облако
        if len(self.clouds) < 8 and randbool(1, 20):
            cx, cy = randcell(self.w, self.h)
            self.clouds.append(Cloud(cx, cy))