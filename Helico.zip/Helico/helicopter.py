from utils import randcell


class Helicopter:
    def __init__(self, w, h):
        rx, ry = randcell(w, h)
        self.w = w
        self.h = h
        self.x = rx
        self.y = ry
        self.tank = 0
        self.max_tank = 1
        self.score = 0
        self.lives = 10
        self.burned = 0

    def move(self, dx, dy):
        nx, ny = self.x + dx, self.y + dy
        if 0 <= nx < self.h and 0 <= ny < self.w:
            self.x, self.y = nx, ny

    def print_stats(self):
        hearts = "❤️" * self.lives
        print(f"🧺 Резервуары: {self.tank}/{self.max_tank}   "
              f"🏆 Очки: {self.score}   {hearts}")