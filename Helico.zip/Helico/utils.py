from random import randint as rand
import json
import os


def randbool(r, mxr):
    t = rand(0, mxr)
    return t <= r


def randcell(w, h):
    tw = rand(0, w - 1)
    th = rand(0, h - 1)
    return (th, tw)


def randcell2(x, y):
    dx = rand(-1, 1)
    dy = rand(-1, 1)
    return (x + dx, y + dy)


# ---- Сохранение/загрузка игры ----
SAVE_FILE = "savegame.json"


def save_game(field, helico, clouds, tick):
    data = {
        "tick": tick,
        "map": {
            "w": field.w,
            "h": field.h,
            "cells": field.cells
        },
        "helico": {
            "x": helico.x,
            "y": helico.y,
            "tank": helico.tank,
            "max_tank": helico.max_tank,
            "score": helico.score,
            "lives": helico.lives
        },
        "clouds": [
            {"x": c.x, "y": c.y, "thunder": c.thunder, "ttl": c.ttl}
            for c in clouds.clouds
        ]
    }
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print("💾 Игра сохранена!")


def load_game(field, helico, clouds):
    if not os.path.exists(SAVE_FILE):
        print("⚠️ Файл сохранения не найден.")
        return None
    with open(SAVE_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data