# 🌲 🌊 🚁 🟩 🔥 🏥 💛 🪣 🏦 🌥️ ⚡ 🏆 ❤️

from pynput import keyboard
from map import Map
from helicopter import Helicopter
from clouds import Clouds
import importer
import exporter
from utils import save_game, load_game, SAVE_FILE
import time
import os

# ⏱ Настройки игры (замедленные)
TICK_SLEEP = 0.5        # было 0.15 — теперь медленнее
TREE_UPDATE = 60        # деревья растут реже
FIRE_UPDATE = 200       # пожары реже
CLOUD_UPDATE = 30       # облака двигаются медленнее

# 🗺 Размер поля
MAP_W, MAP_H = 20, 10

# Создание объектов
field = Map(MAP_W, MAP_H)
helico = Helicopter(MAP_W, MAP_H)
clouds = Clouds(MAP_W, MAP_H, 6)

field.generate_forest(7, 10)
field.generate_river(10)
field.generate_river(8)
field.generate_hospital()
field.generate_shop()

MOVES = {'w': (-1, 0), 'd': (0, 1), 's': (1, 0), 'a': (0, -1)}
running = True


def process_key(key):
    global running, tick
    try:
        c = key.char.lower()

        # выход
        if c == 'q':
            running = False
            listener.stop()
            return

        # движение
        if c in MOVES:
            dx, dy = MOVES[c]
            helico.move(dx, dy)

        # сбросить воду на огонь
        elif c == 'e':
            if helico.tank > 0 and field.cells[helico.x][helico.y] == 5:
                field.cells[helico.x][helico.y] = 0
                helico.tank -= 1
                helico.score += 10

        # купить воду
        elif c == 'b':
            importer.buy_water(helico)

        # апгрейд в магазине 🏦
        elif c == 'u':
            if field.cells[helico.x][helico.y] == 4:
                importer.upgrade_tank(helico)

        # лечение в госпитале 🏥
        elif c == 'h':
            if field.cells[helico.x][helico.y] == 3:
                importer.heal(helico)

        # продать дерево
        elif c == 'x':
            exporter.sell_wood(helico, field)

        # 💾 сохранить
        elif c == 'k':
            save_game(field, helico, clouds, tick)

    except AttributeError:
        pass


listener = keyboard.Listener(on_press=process_key)
listener.start()

tick = 1

while running:
    os.system("clear")
    print(f"===== TICK {tick} =====")
    helico.print_stats()
    print("WASD – лететь | E – сбросить воду | B – купить воду (20🏆)")
    print("U – апгрейд в 🏦 (100🏆) | H – лечение в 🏥 (50🏆)")
    print("X – спилить дерево (30🏆) | K – сохранить | Q – выход")
    print()
    field.print_map(helico, clouds)

    # 🚰 заправка водой над рекой
    if field.cells[helico.x][helico.y] == 2:
        if helico.tank < helico.max_tank:
            helico.tank += 1

    # 🔥 урон от огня
    if field.cells[helico.x][helico.y] == 5:
        helico.burned += 1
        if helico.burned >= 10:
            helico.lives -= 1
            helico.burned = 0
            if helico.lives <= 0:
                print("\n💀 Вертолёт сгорел! Игра окончена.")
                break
    else:
        helico.burned = 0

    tick += 1
    time.sleep(TICK_SLEEP)

    # ⏳ обновления
    if tick % TREE_UPDATE == 0:
        field.generate_tree()
    if tick % FIRE_UPDATE == 0:
        field.generate_fire()
    if tick % CLOUD_UPDATE == 0:
        clouds.update(field)

    # обновление огня
    field.update_fires(helico)

print(f"\n🏁 Игра окончена. Ваш счёт: {helico.score}")