# Магазин 🏦 и госпиталь 🏥


def buy_water(helico, cost=20):
    if helico.score >= cost:
        helico.score -= cost
        helico.tank = helico.max_tank
        return True
    return False


def upgrade_tank(helico, cost=100):
    if helico.score >= cost:
        helico.score -= cost
        helico.max_tank += 1
        return True
    return False


def heal(helico, cost=50):
    if helico.score >= cost and helico.lives < 10:
        helico.score -= cost
        helico.lives += 1
        return True
    return False