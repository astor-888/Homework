from utils import randbool, randcell, randcell2

# 0 - поле 🟩
# 1 - дерево 🌲
# 2 - река 🌊
# 3 - госпиталь 🏥
# 4 - магазин 🏦
# 5 - огонь 🔥

CELL_TYPES = ["🟩", "🌲", "🌊", "🏥", "🏦", "🔥"]


class Map:
    def __init__(self, w, h):
        self.w = w
        self.h = h
        self.cells = [[0 for _ in range(w)] for _ in range(h)]

    def generate_forest(self, r, mxr):
        for ri in range(self.h):
            for ci in range(self.w):
                if randbool(r, mxr):
                    self.cells[ri][ci] = 1

    def generate_river(self, l):
        rx, ry = randcell(self.w, self.h)
        self.cells[rx][ry] = 2
        while l > 0:
            rx2, ry2 = randcell2(rx, ry)
            if self.check_bounds(rx2, ry2):
                self.cells[rx2][ry2] = 2
                rx, ry = rx2, ry2
                l -= 1

    def generate_tree(self):
        cx, cy = randcell(self.w, self.h)
        if self.cells[cx][cy] == 0:
            self.cells[cx][cy] = 1

    def generate_fire(self):
        for _ in range(50):
            cx, cy = randcell(self.w, self.h)
            if self.cells[cx][cy] == 1:
                self.cells[cx][cy] = 5
                return

    def generate_hospital(self):
        for _ in range(200):
            cx, cy = randcell(self.w, self.h)
            if self.cells[cx][cy] == 0:
                self.cells[cx][cy] = 3
                return

    def generate_shop(self):
        for _ in range(200):
            cx, cy = randcell(self.w, self.h)
            if self.cells[cx][cy] == 0:
                self.cells[cx][cy] = 4
                return

    def update_fires(self, helico):
        """Огонь распространяется медленно, горит долго."""
        new_fires = []
        burned = []
        for ri in range(self.h):
            for ci in range(self.w):
                if self.cells[ri][ci] == 5:
                    # распространение (реже)
                    for _ in range(4):
                        rx, ry = randcell2(ri, ci)
                        if self.check_bounds(rx, ry) and self.cells[rx][ry] == 1:
                            if randbool(1, 10):
                                new_fires.append((rx, ry))
                    # огонь гаснет сам (очень редко)
                    if randbool(1, 30):
                        burned.append((ri, ci))
        for rx, ry in new_fires:
            self.cells[rx][ry] = 5
        for rx, ry in burned:
            self.cells[rx][ry] = 0   # сгоревшее дерево → поле
            helico.score -= 5
            if helico.score < 0:
                helico.score = 0

    def check_bounds(self, x, y):
        return 0 <= x < self.h and 0 <= y < self.w

    def print_map(self, helico, clouds):
        print("⬛" * (self.w + 2))
        for ri in range(self.h):
            print("⬛", end="")
            for ci in range(self.w):
                # облака и вертолёт рисуются поверх
                cloud_here = None
                for c in clouds.clouds:
                    if c.x == ri and c.y == ci:
                        cloud_here = c
                        break
                if helico.x == ri and helico.y == ci:
                    print("🚁", end="")
                elif cloud_here is not None:
                    if cloud_here.thunder:
                        print("⚡", end="")
                    else:
                        print("☁️", end="")
                else:
                    cell = self.cells[ri][ci]
                    if 0 <= cell < len(CELL_TYPES):
                        print(CELL_TYPES[cell], end="")
                    else:
                        print("?", end="")
            print("⬛")
        print("⬛" * (self.w + 2))